import React from "react";
import ReactDOM from "react-dom";
import LoginView from "./containers/login";

ReactDOM.render(
    <LoginView />,
  document.querySelector("#root")
);
