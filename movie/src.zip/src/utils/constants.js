export const LOGIN_API = "http://127.0.0.1:8000/api/login";
export const SIGNUP_API = "http://127.0.0.1:8000/api/signup";
