import React from "react";
import { FormField, Button, Card } from "../components";

class SignUpView extends React.Component {
  render() {
    return (
      <Card>
      <form >
        <FormField
          name="first_name"
          field="First Name"
          type="text"
          icon="fa-user"
        />
        <FormField
          name="last_name"
          field="Last Name"
          type="text"
          icon="fa-user"
        />
        {/* <Select options={["male", "female"]} /> */}
        <Button text="SignUp" />
        
      </form>
    </Card>
    );
  }
}

export { SignUpView };
