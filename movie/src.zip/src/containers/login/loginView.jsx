import React from "react";
import { FormField, Button, Card } from "../../components";

class LoginView extends React.Component {
  handleLogin = e => {
    e.preventDefault();
    const {email, password} = e.target;
    return {
      email: email.value,
      password: password.value
    };
  };

  render() {
    console.log(this.props);
    return (
      <Card>
        <form onSubmit={this.handleLogin}>
          <FormField name="email" field="Email" type="text" icon="fa-user" />
          <FormField name="password" field="Password" type="password" icon="fa-key" />
          <Button text="Login" />
          <a href="#">Create Account</a>
        </form>
      </Card>
    );
  }
}

export { LoginView };
