import {connect} from "react-redux";
import {LoginView} from "./loginView";
import {loginUser} from '../../actions/login';

const mapStateToProps = ({user}) => user;

const mapDispatchToProps = () => ({
    auth: loginUser,
});

const LoginContainer = connect(mapStateToProps,mapDispatchToProps)(LoginView);
export default LoginContainer;
