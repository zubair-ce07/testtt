import React from "react";
import "./select.css";

const Select = ({ options }) => {
  const selectOptions = options.map(option => {
    return <option value={option}>{option}</option>;
  });
  return <select>{selectOptions}</select>;
};

export { Select };
