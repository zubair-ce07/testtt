import axios from "axios";
import {
  LOGIN_USER_fAILURE,
  LOGIN_USER_STARTED,
  LOGIN_USER_SUCCESS
} from "./types";
import {LOGIN_API} from "../utils/constants";

const loginUserStarted = () => ({
    type: LOGIN_USER_STARTED
  });
  
  const loginUserSuccess = user => ({
    type: LOGIN_USER_SUCCESS,
    payload: {
      user
    }
  });
  
  const loginUserFailure = error => ({
    type: LOGIN_USER_fAILURE,
    payload: {
      error
    }
  });

export const loginUser = ({ email, password }) => {
  return dispatch => {
    dispatch(loginUserStarted());
    axios.post(LOGIN_API, {email, password})
    .then(res => dispatch(loginUserSuccess(res.data)))
    .catch(err => dispatch(loginUserFailure(err.message)));
  };
};

